<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Image Upload</title>
        <link rel="stylesheet" href="public/css/bootstrap.css">
        <link rel="stylesheet" href="public/css/bootstrap-grid.css">
        <link rel="stylesheet" href="public/css/bootstrap-reboot.css">
        <script src="public/js/jquery-3.3.1.min.js"></script>
        <script src="public/js/bootstrap.bundle.js"></script>

        <link rel="stylesheet" href="app.css">
    </head>
    <body>
    <div class="container pt-3">
        <?php
            if(($_SERVER['REQUEST_METHOD'] === 'GET') && ($_SESSION['authenticated'] !== true)){
                echo returnLogin();
            } else if($_SERVER['REQUEST_METHOD'] === 'GET'){
                echo returnBody();
            }

        if($_SERVER['REQUEST_METHOD'] === 'POST' && $_SESSION['authenticated'] !== true){
            //Verify Username and Password

            if(verifyLogin($_POST['username'],$_POST['password'])){
                $_SESSION['authenticated'] = true;
                echo returnBody();
            } else {
                echo returnLogin();
                echo '<script>alert("Invalid Username or Password");</script>';
            }
        } else if($_SERVER['REQUEST_METHOD'] === 'POST'){
            //Accept the file upload
            $image_dir = "public/images";
            echo 'Got It';
        }
        ?>
    </div>


    <?php
        function returnBody(){
            $returnString = '<div class="col">';
            $returnString .= '<div class="card">';
            $returnString .= '<table><thead><th>Link</th><th>Description</th><th>Category</th></thead></table>';
            $returnString .= '</div>';
            $returnString .= '<div class="card mt-3">';
            $returnString .= '<h5 class="card-header">Add Image</h5>';
            $returnString .= '<div class="card-body">';
            $returnString .= '<form method="post" enctype="multipart/form-data">';
            $returnString .= '<input type="file" accept="image/*" name="image">';
            $returnString .= '<select>';
            $returnString .= '<option value="memes">Memes</option>';
            $returnString .= '<option value="family">Family Photos</option>';
            $returnString .= '<option value="other">Other</option>';
            $returnString .= '<select>';
            $returnString .= '<div class="form-group"><label for="comment">Comments</label><textarea class="form-control" rows="5" id="comment" name="comment"></textarea></div>';
            $returnString .= '<button type="submit" class="btn btn-primary">Submit</button>';
            $returnString .= '</form>';
            $returnString .= '</div>';
            $returnString .= '</div>';
            $returnString .= '</div>';

            $returnString .= '<a href="logout.php" class="btn btn-danger mt-3">Logout</a>';


            return $returnString;
        }

        function returnLogin(){
            $returnString = '<div class="card"><div class="card-body pt-3"><form method="post">';
            $returnString .= '<img src="public/upload.png" class="rounded mx-auto d-block" alt="Upload Image" height="25%" width="25%">';
            $returnString .= '<div class="form-group">';
            $returnString .= '<label for="">Username</label><input id="username" class="form-control" type="text" name="username"></div><div class="form-group"><label>Password</label><input id="password" class="form-control" type="password" name="password">';
            $returnString .= '</div><button type="submit" class="btn btn-primary">Login</button></form></div></div>';

            return $returnString;
        }

        function verifyLogin($username, $password){
            $servername = "localhost";
            $db_username = "jbeneski_images";
            $db_password = "cjcW4e!Uo*bH";
            $dbname = "jbeneski_images";

            $conn = new mysqli($servername, $db_username, $db_password, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT * FROM `users` WHERE username='$username'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "Username: " . $row["username"]. " Password: " . $row["password"]. "<br>";
                    if($row['username']=== $username && $row['password'] === $password){
                        $conn->close();
                        return true;
                    }
                }
                $conn->close();
                return false;
            } else {
                $conn->close();
                return false;
            }
        }
    ?>
    </body>
</html>